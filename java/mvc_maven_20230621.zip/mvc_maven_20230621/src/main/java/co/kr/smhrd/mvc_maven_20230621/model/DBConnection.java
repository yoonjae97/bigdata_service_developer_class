package co.kr.smhrd.mvc_maven_20230621.model;

import java.lang.module.Configuration;
import java.sql.Connection;
import java.sql.DriverManager;

import oracle.jdbc.driver.OracleDriver;
// 싱글톤 패턴 : 객체를 하나 만들고 계속 재사용하는 디자인 패턴
public class DBConnection {
    private static Connection conn;
    private static String url="jdbc:oracle:thin:@localhost:1521:XE";
    private static String user="c##smart01";
    private static String pw="oracle01";
    private static String driver="oracle.jdbc.driver.OracleDriver";

    public static Connection getInstance() throws Exception{
        if(conn==null || conn.isClosed()) {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pw);
        }
        return conn;
    }
}
