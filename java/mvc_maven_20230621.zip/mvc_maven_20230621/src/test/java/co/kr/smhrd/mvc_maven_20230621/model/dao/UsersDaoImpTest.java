package co.kr.smhrd.mvc_maven_20230621.model.dao;

import co.kr.smhrd.mvc_maven_20230621.dto.UsersDto;
import co.kr.smhrd.mvc_maven_20230621.model.DBConnection;
import org.junit.jupiter.api.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*; // 테스트를 상세하게 진행하도록 돕는다.
@TestMethodOrder(MethodOrderer.OrderAnnotation.class) //@Test @Order(1~) : order 정의한 순서대로 test 진행
class UsersDaoImpTest {
    private static UsersDao userDao;
    @BeforeAll // @Test 들이 시작되기 전에 시작
    static void init() throws Exception {
        userDao = new UsersDaoImp(DBConnection.getInstance());
    }

    // @Test : 단위 테스트로 @Test 간에는 순서가 존재하지 않는다.
    @Order(2)
    @Test
    void findByUIdAndPw() throws Exception {
        UsersDto user = (userDao.findByUIdAndPw("U999","1234"));
        System.out.println(user.toString());
        assertNotNull(user);
    }
    @Order(3)
    @Test
    void findByUId() throws Exception {
        UsersDto user=userDao.findByUId("U003");
        System.out.println(user);
    }
    @Order(4)
    @Test
    void updateOne() throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // 문자열을 Date 객체로 변환, Date->문자열로
        Date birth=sdf.parse("1997-11-20");
        UsersDto user = new UsersDto();
        user.setUId("U002");
        user.setPw("1234");
        user.setName("yj");
        user.setBirth(birth); // dto 만들때 sql.Date 문자열로 처리할것
        // 오라클 timestamp == java.util.date
        user.setProfilePath("/test/경로.jpg");
        user.setState("LEAVE");
        user.setGender('F');
        int update = 0;
        update = userDao.updateOne(user);
        assertTrue(update>0);

    }
    @Order(1)
    @Test
    void insertOne() throws Exception {
        int insert=0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // 문자열을 Date 객체로 변환, Date->문자열로
        Date birth=sdf.parse("1999-11-20");
        UsersDto user = new UsersDto();
        user.setUId("U999");
        user.setPw("1234");
        user.setName("test");
        user.setBirth(birth);
        user.setProfilePath("/test/U999.jpg");
        user.setGender('M');
        insert=userDao.insertOne(user);
        assertTrue(insert>0);

    }
    @Order(5)
    @Test
    void deleteByUIdAndPw() throws Exception {
        int delete= userDao.deleteByUIdAndPw("U999","1234");
        assertTrue(delete>0);
    }
}